<?php

namespace Yajra\DataTables\Html;

use Illuminate\Support\Collection;

class ColumnDefinitions extends Collection
{

}

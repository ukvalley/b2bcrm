<?php

namespace Yajra\DataTables\Html\Editor\Fields;

class Radio extends Field
{
    protected string $type = 'radio';
}

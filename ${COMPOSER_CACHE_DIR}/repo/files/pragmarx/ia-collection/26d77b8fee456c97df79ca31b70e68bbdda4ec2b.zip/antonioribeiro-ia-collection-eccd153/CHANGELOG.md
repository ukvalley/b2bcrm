# Changelog

## v0.3.0 - 2018-01-21
### Changed
Upgrade script is now using Illuminate\Support\Collection directly.
Tagging versions using the current Laravel version number.
### Added
More tests

## v0.1.9 - 2018-01-14
### Changed
Allow properties to be retrieved as lower or upper case

## v0.1.6 - 2017-12-07 
### Changed
- Fixes

## v0.1.0 - 2017-10-28
### Added
- First working version

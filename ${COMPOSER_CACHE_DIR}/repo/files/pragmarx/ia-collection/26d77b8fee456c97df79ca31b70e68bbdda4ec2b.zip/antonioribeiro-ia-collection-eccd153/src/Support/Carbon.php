<?php

namespace IlluminateAgnostic\Collection\Support;

use Carbon\Carbon as BaseCarbon;

class Carbon extends BaseCarbon
{
    //
}

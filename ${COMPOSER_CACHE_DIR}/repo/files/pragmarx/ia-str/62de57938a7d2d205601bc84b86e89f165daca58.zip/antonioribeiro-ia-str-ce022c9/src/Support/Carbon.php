<?php

namespace IlluminateAgnostic\Str\Support;

use Carbon\Carbon as BaseCarbon;

class Carbon extends BaseCarbon
{
    //
}

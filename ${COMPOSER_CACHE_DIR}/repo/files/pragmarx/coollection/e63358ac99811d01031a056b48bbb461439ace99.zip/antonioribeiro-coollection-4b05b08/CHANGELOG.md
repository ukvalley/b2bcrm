# Changelog

## v0.6.0 - 2018-08-19
### Added
Improve search by key with any case, snake, camel, kebab, string

## v0.5.7 - 2018-02-18
### Changed
Added sortByKey() method
### Added
More tests

## v0.5.4 - 2018-02-18
### Changed
Huge improvements in speed
### Added
More tests

## v0.5.3 - 2018-02-17
## v0.5.2 - 2018-02-13
## v0.5.1 - 2018-02-13
### Fixed
Some bugs squashed

## v0.5.0 - 2018-01-21
### Changed
Upgrade script is now using Illuminate\Support\Collection directly.
Tagging versions using the current Laravel version number.
### Added
More tests

## v0.1.9 - 2018-01-14
### Changed
Allow properties to be retrieved as lower or upper case

## v0.1.6 - 2017-12-07 
### Changed
- Fixes

## v0.1.0 - 2017-10-28
### Added
- First working version

Nette Finder: Files Searching
=============================

Nette Finder makes browsing the directory structure really easy.

Documentation can be found on the [website](https://doc.nette.org/utils/finder).

**The library has been moved to the [nette/utils](https://github.com/nette/utils)**
